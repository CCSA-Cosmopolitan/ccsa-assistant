"use client"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Loader2, Droplets, TreesIcon as Plant, FlaskRoundIcon as Flask } from "lucide-react"

interface SoilData {
  ph: number
  nitrogen: string
  phosphorus: string
  potassium: string
  organicMatter: string
  moisture: number
  texture: string
  temperature: string
  location: string
  depth: string
}

interface AnalysisResult {
  recommendedCrops: string[]
  fertilizers: {
    type: string
    amount: string
    frequency: string
  }[]
  wateringSchedule: {
    frequency: string
    amount: string
    notes: string
  }
  additionalNotes: string
}

export default function SoilAnalyzer() {
  const [loading, setLoading] = useState(false)
  const [soilData, setSoilData] = useState<SoilData>({
    ph: 7.0,
    nitrogen: "0",
    phosphorus: "0",
    potassium: "0",
    organicMatter: "0",
    moisture: 50,
    texture: "",
    temperature: "20",
    location: "",
    depth: "30",
  })
  const [result, setResult] = useState<AnalysisResult | null>(null)

  const handleAnalyze = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/analyze-soil", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(soilData),
      })
      const data = await response.json()
      setResult(data)
    } catch (error) {
      console.error("Error analyzing soil:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold text-center mb-8">AI Soil Analyzer</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Soil Parameters</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div>
                <Label>Soil pH ({soilData.ph.toFixed(1)})</Label>
                <Slider
                  min={0}
                  max={14}
                  step={0.1}
                  value={[soilData.ph]}
                  onValueChange={([ph]) => setSoilData({ ...soilData, ph })}
                  className="mt-2"
                />
              </div>

              <div>
                <Label>Soil Texture</Label>
                <Select value={soilData.texture} onValueChange={(texture) => setSoilData({ ...soilData, texture })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select soil texture" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sandy">Sandy</SelectItem>
                    <SelectItem value="loamy">Loamy</SelectItem>
                    <SelectItem value="clay">Clay</SelectItem>
                    <SelectItem value="silty">Silty</SelectItem>
                    <SelectItem value="peaty">Peaty</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label>N (%)</Label>
                  <Input
                    type="number"
                    min="0"
                    max="100"
                    step="0.1"
                    value={soilData.nitrogen}
                    onChange={(e) => setSoilData({ ...soilData, nitrogen: e.target.value })}
                  />
                </div>
                <div>
                  <Label>P (%)</Label>
                  <Input
                    type="number"
                    min="0"
                    max="100"
                    step="0.1"
                    value={soilData.phosphorus}
                    onChange={(e) => setSoilData({ ...soilData, phosphorus: e.target.value })}
                  />
                </div>
                <div>
                  <Label>K (%)</Label>
                  <Input
                    type="number"
                    min="0"
                    max="100"
                    step="0.1"
                    value={soilData.potassium}
                    onChange={(e) => setSoilData({ ...soilData, potassium: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <Label>Organic Matter (%)</Label>
                <Input
                  type="number"
                  min="0"
                  max="100"
                  step="0.1"
                  value={soilData.organicMatter}
                  onChange={(e) => setSoilData({ ...soilData, organicMatter: e.target.value })}
                />
              </div>

              <div>
                <Label>Soil Moisture (%) - {soilData.moisture}%</Label>
                <Slider
                  min={0}
                  max={100}
                  step={1}
                  value={[soilData.moisture]}
                  onValueChange={([moisture]) => setSoilData({ ...soilData, moisture })}
                />
              </div>

              <div>
                <Label>Soil Temperature (°C)</Label>
                <Input
                  type="number"
                  value={soilData.temperature}
                  onChange={(e) => setSoilData({ ...soilData, temperature: e.target.value })}
                />
              </div>

              <div>
                <Label>Location</Label>
                <Input
                  value={soilData.location}
                  onChange={(e) => setSoilData({ ...soilData, location: e.target.value })}
                  placeholder="Enter location"
                />
              </div>

              <div>
                <Label>Soil Depth (cm)</Label>
                <Input
                  type="number"
                  value={soilData.depth}
                  onChange={(e) => setSoilData({ ...soilData, depth: e.target.value })}
                />
              </div>

              <Button className="w-full" onClick={handleAnalyze} disabled={loading || !soilData.texture}>
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  "Analyze Soil"
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Analysis Results</CardTitle>
          </CardHeader>
          <CardContent>
            {result ? (
              <Tabs defaultValue="crops">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="crops">
                    <Plant className="mr-2 h-4 w-4" />
                    Crops
                  </TabsTrigger>
                  <TabsTrigger value="fertilizer">
                    <Flask className="mr-2 h-4 w-4" />
                    Fertilizer
                  </TabsTrigger>
                  <TabsTrigger value="watering">
                    <Droplets className="mr-2 h-4 w-4" />
                    Watering
                  </TabsTrigger>
                </TabsList>
                <TabsContent value="crops" className="space-y-4">
                  <h3 className="font-semibold">Recommended Crops</h3>
                  <ul className="list-disc pl-5 space-y-2">
                    {result.recommendedCrops.map((crop, index) => (
                      <li key={index}>{crop}</li>
                    ))}
                  </ul>
                </TabsContent>
                <TabsContent value="fertilizer" className="space-y-4">
                  <h3 className="font-semibold">Fertilizer Recommendations</h3>
                  {result.fertilizers.map((fertilizer, index) => (
                    <div key={index} className="border p-3 rounded-lg">
                      <p className="font-medium">{fertilizer.type}</p>
                      <p className="text-sm text-gray-600">Amount: {fertilizer.amount}</p>
                      <p className="text-sm text-gray-600">Frequency: {fertilizer.frequency}</p>
                    </div>
                  ))}
                </TabsContent>
                <TabsContent value="watering" className="space-y-4">
                  <h3 className="font-semibold">Watering Schedule</h3>
                  <div className="border p-3 rounded-lg">
                    <p>Frequency: {result.wateringSchedule.frequency}</p>
                    <p>Amount: {result.wateringSchedule.amount}</p>
                    <p className="text-sm text-gray-600 mt-2">{result.wateringSchedule.notes}</p>
                  </div>
                </TabsContent>
              </Tabs>
            ) : (
              <div className="text-center text-gray-500 py-8">
                Enter soil parameters and click Analyze to get recommendations
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}



// "use client"
// import { useState } from "react"
// import { Button } from "@/components/ui/button"
// import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
// import { Input } from "@/components/ui/input"
// import { Label } from "@/components/ui/label"
// import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
// import { Slider } from "@/components/ui/slider"
// import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
// import { Loader2, Droplets, TreesIcon as Plant, FlaskRoundIcon as Flask } from "lucide-react"

// interface SoilData {
//   ph: number
//   nitrogen: number
//   phosphorus: number
//   potassium: number
//   organicMatter: number
//   moisture: number
//   texture: string
//   temperature: number
//   location: string
//   depth: number
// }

// interface AnalysisResult {
//   recommendedCrops: string[]
//   fertilizers: {
//     type: string
//     amount: string
//     frequency: string
//   }[]
//   wateringSchedule: {
//     frequency: string
//     amount: string
//     notes: string
//   }
//   additionalNotes: string
// }

// export default function SoilAnalyzer() {
//   const [loading, setLoading] = useState(false)
//   const [soilData, setSoilData] = useState<SoilData>({
//     ph: 7,
//     nitrogen: 0,
//     phosphorus: 0,
//     potassium: 0,
//     organicMatter: 0,
//     moisture: 0,
//     texture: "",
//     temperature: 20,
//     location: "",
//     depth: 30,
//   })
//   const [result, setResult] = useState<AnalysisResult | null>(null)

//   const handleAnalyze = async () => {
//     setLoading(true)
//     try {
//       const response = await fetch("/api/analyze-soil", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify(soilData),
//       })
//       const data = await response.json()
//       setResult(data)
//     } catch (error) {
//       console.error("Error analyzing soil:", error)
//     } finally {
//       setLoading(false)
//     }
//   }

//   return (
//     <div className="container mx-auto px-10 py-8">
//       <h1 className="text-3xl font-bold text-center mb-4">AI Soil Analyzer</h1>
//       <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
//         <Card>
//           <CardHeader>
//             <CardTitle>Soil Parameters</CardTitle>
//           </CardHeader>
//           <CardContent className="space-y-6">
//             <div className="space-y-4">
//               <div>
//                 <Label>Soil pH ({soilData.ph})</Label>
//                 <Slider
//                   min={0}
//                   max={14}
//                   step={0.1}
//                   value={[soilData.ph]}
//                   onValueChange={([ph]) => setSoilData({ ...soilData, ph })}
//                   className="mt-2"
//                 />
//               </div>

//               <div>
//                 <Label>Soil Texture</Label>
//                 <Select value={soilData.texture} onValueChange={(texture) => setSoilData({ ...soilData, texture })}>
//                   <SelectTrigger>
//                     <SelectValue placeholder="Select soil texture" />
//                   </SelectTrigger>
//                   <SelectContent>
//                     <SelectItem value="sandy">Sandy</SelectItem>
//                     <SelectItem value="loamy">Loamy</SelectItem>
//                     <SelectItem value="clay">Clay</SelectItem>
//                     <SelectItem value="silty">Silty</SelectItem>
//                     <SelectItem value="peaty">Peaty</SelectItem>
//                   </SelectContent>
//                 </Select>
//               </div>

//               <div className="grid grid-cols-3 gap-4">
//                 <div>
//                   <Label>N (%)</Label>
//                   <Input
//                     type="number"
//                     min="0"
//                     max="100"
//                     step="0.1"
//                     value={soilData.nitrogen}
//                     onChange={(e) => setSoilData({ ...soilData, nitrogen: Number.parseFloat(e.target.value) })}
//                   />
//                 </div>
//                 <div>
//                   <Label>P (%)</Label>
//                   <Input
//                     type="number"
//                     min="0"
//                     max="100"
//                     step="0.1"
//                     value={soilData.phosphorus}
//                     onChange={(e) => setSoilData({ ...soilData, phosphorus: Number.parseFloat(e.target.value) })}
//                   />
//                 </div>
//                 <div>
//                   <Label>K (%)</Label>
//                   <Input
//                     type="number"
//                     min="0"
//                     max="100"
//                     step="0.1"
//                     value={soilData.potassium}
//                     onChange={(e) => setSoilData({ ...soilData, potassium: Number.parseFloat(e.target.value) })}
//                   />
//                 </div>
//               </div>

//               <div>
//                 <Label>Organic Matter (%)</Label>
//                 <Input
//                   type="number"
//                   min="0"
//                   max="100"
//                   step="0.1"
//                   value={soilData.organicMatter}
//                   onChange={(e) => setSoilData({ ...soilData, organicMatter: Number.parseFloat(e.target.value) })}
//                 />
//               </div>

//               <div>
//                 <Label>Soil Moisture (%)</Label>
//                 <Slider
//                   min={0}
//                   max={100}
//                   step={1}
//                   value={[soilData.moisture]}
//                   onValueChange={([moisture]) => setSoilData({ ...soilData, moisture })}
//                 />
//               </div>

//               <div>
//                 <Label>Soil Temperature (°C)</Label>
//                 <Input
//                   type="number"
//                   value={soilData.temperature}
//                   onChange={(e) => setSoilData({ ...soilData, temperature: Number.parseFloat(e.target.value) })}
//                 />
//               </div>

//               <div>
//                 <Label>Location</Label>
//                 <Input
//                   value={soilData.location}
//                   onChange={(e) => setSoilData({ ...soilData, location: e.target.value })}
//                   placeholder="Enter location"
//                 />
//               </div>

//               <Button className="w-full" onClick={handleAnalyze} disabled={loading}>
//                 {loading ? (
//                   <>
//                     <Loader2 className="mr-2 h-4 w-4 animate-spin" />
//                     Analyzing...
//                   </>
//                 ) : (
//                   "Analyze Soil"
//                 )}
//               </Button>
//             </div>
//           </CardContent>
//         </Card>

//         <Card>
//           <CardHeader>
//             <CardTitle>Analysis Results</CardTitle>
//           </CardHeader>
//           <CardContent>
//             {result ? (
//               <Tabs defaultValue="crops">
//                 <TabsList className="grid w-full grid-cols-3">
//                   <TabsTrigger value="crops">
//                     <Plant className="mr-2 h-4 w-4" />
//                     Crops
//                   </TabsTrigger>
//                   <TabsTrigger value="fertilizer">
//                     <Flask className="mr-2 h-4 w-4" />
//                     Fertilizer
//                   </TabsTrigger>
//                   <TabsTrigger value="watering">
//                     <Droplets className="mr-2 h-4 w-4" />
//                     Watering
//                   </TabsTrigger>
//                 </TabsList>
//                 <TabsContent value="crops" className="space-y-4">
//                   <h3 className="font-semibold">Recommended Crops</h3>
//                   <ul className="list-disc pl-5 space-y-2">
//                     {result.recommendedCrops.map((crop, index) => (
//                       <li key={index}>{crop}</li>
//                     ))}
//                   </ul>
//                 </TabsContent>
//                 <TabsContent value="fertilizer" className="space-y-4">
//                   <h3 className="font-semibold">Fertilizer Recommendations</h3>
//                   {result.fertilizers.map((fertilizer, index) => (
//                     <div key={index} className="border border-green-600 p-3 rounded-lg">
//                       <p className="font-medium">{fertilizer.type}</p>
//                       <p className="text-sm text-gray-600">Amount: {fertilizer.amount}</p>
//                       <p className="text-sm text-gray-600">Frequency: {fertilizer.frequency}</p>
//                     </div>
//                   ))}
//                 </TabsContent>
//                 <TabsContent value="watering" className="space-y-4">
//                   <h3 className="font-semibold">Watering Schedule</h3>
//                   <div className="border p-3 rounded-lg">
//                     <p>Frequency: {result.wateringSchedule.frequency}</p>
//                     <p>Amount: {result.wateringSchedule.amount}</p>
//                     <p className="text-sm text-gray-600 mt-2">{result.wateringSchedule.notes}</p>
//                   </div>
//                 </TabsContent>
//               </Tabs>
//             ) : (
//               <div className="text-center text-gray-500 py-8">
//                 Enter soil parameters and click Analyze to get recommendations
//               </div>
//             )}
//           </CardContent>
//         </Card>
//       </div>
//     </div>
//   )
// }

