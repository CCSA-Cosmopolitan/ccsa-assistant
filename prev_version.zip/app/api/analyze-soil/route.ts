import { NextResponse } from "next/server"
import OpenAI from "openai"

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

// Define a default response structure
const defaultAnalysis = {
  recommendedCrops: [],
  fertilizers: [],
  wateringSchedule: {
    frequency: "",
    amount: "",
    notes: "",
  },
  additionalNotes: "",
}

export async function POST(request: Request) {
  try {
    const soilData = await request.json()

    const completion = await openai.chat.completions.create({
      messages: [
        {
          role: "system",
          content:
            "You are an expert agricultural analyst. Provide recommendations in JSON format only. Ensure the response is a valid JSON object with recommendedCrops (array), fertilizers (array of objects with type, amount, and frequency), wateringSchedule (object with frequency, amount, and notes), and additionalNotes (string).",
        },
        {
          role: "user",
          content: `Analyze these soil parameters and provide detailed recommendations:
            - pH: ${soilData.ph}
            - Texture: ${soilData.texture}
            - Nitrogen: ${soilData.nitrogen}%
            - Phosphorus: ${soilData.phosphorus}%
            - Potassium: ${soilData.potassium}%
            - Organic Matter: ${soilData.organicMatter}%
            - Moisture: ${soilData.moisture}%
            - Temperature: ${soilData.temperature}°C
            - Location: ${soilData.location}
            - Depth: ${soilData.depth}cm

            Return the analysis in this exact JSON format:
            {
              "recommendedCrops": ["crop1", "crop2", "crop3"],
              "fertilizers": [
                {
                  "type": "fertilizer name",
                  "amount": "amount per application",
                  "frequency": "application frequency"
                }
              ],
              "wateringSchedule": {
                "frequency": "how often to water",
                "amount": "amount of water",
                "notes": "additional watering instructions"
              },
              "additionalNotes": "any other important information"
            }`,
        },
      ],
      model: "gpt-4",
      temperature: 0.7,
      max_tokens: 1000,
    })

    const responseText = completion.choices[0].message.content

    try {
      const analysisResult = JSON.parse(responseText || "{}")
      // Validate the structure and provide defaults for missing properties
      return NextResponse.json({
        recommendedCrops: analysisResult.recommendedCrops || defaultAnalysis.recommendedCrops,
        fertilizers: analysisResult.fertilizers || defaultAnalysis.fertilizers,
        wateringSchedule: {
          frequency: analysisResult.wateringSchedule?.frequency || defaultAnalysis.wateringSchedule.frequency,
          amount: analysisResult.wateringSchedule?.amount || defaultAnalysis.wateringSchedule.amount,
          notes: analysisResult.wateringSchedule?.notes || defaultAnalysis.wateringSchedule.notes,
        },
        additionalNotes: analysisResult.additionalNotes || defaultAnalysis.additionalNotes,
      })
    } catch (parseError) {
      console.error("Error parsing AI response:", responseText)
      return NextResponse.json(defaultAnalysis)
    }
  } catch (error) {
    console.error("Error:", error)
    return NextResponse.json(defaultAnalysis)
  }
}



// import OpenAI from "openai"

// // Create an OpenAI API client
// const openai = new OpenAI({
//   apiKey: process.env.OPENAI_API_KEY,
// })

// // IMPORTANT! Set the runtime to edge
// export const runtime = "edge"

// export async function POST(req: Request) {
//   try {
//     // Extract the `messages` from the body of the request
//     const { ph, texture, nitrogen, phosphorus, potassium, organicMatter, moisture, temperature, location, depth } =
//       await req.json()

//     // Ask OpenAI for a streaming chat completion given the prompt
//     const response = await openai.chat.completions.create({
//       model: "gpt-4",
//       stream: false,
//       messages: [
//         {
//           role: "system",
//           content: `You are an expert agricultural analyst. Analyze soil parameters and provide recommendations in JSON format.`,
//         },
//         {
//           role: "user",
//           content: `Analyze these soil parameters and provide recommendations:
//             - pH: ${ph}
//             - Texture: ${texture}
//             - Nitrogen: ${nitrogen}%
//             - Phosphorus: ${phosphorus}%
//             - Potassium: ${potassium}%
//             - Organic Matter: ${organicMatter}%
//             - Moisture: ${moisture}%
//             - Temperature: ${temperature}°C
//             - Location: ${location}
//             - Depth: ${depth}cm

//             Provide recommendations in this exact JSON format:
//             {
//               "recommendedCrops": ["crop1", "crop2", "crop3"],
//               "fertilizers": [
//                 {
//                   "type": "fertilizer name",
//                   "amount": "amount per application",
//                   "frequency": "application frequency"
//                 }
//               ],
//               "wateringSchedule": {
//                 "frequency": "how often to water",
//                 "amount": "amount of water",
//                 "notes": "additional watering instructions"
//               },
//               "additionalNotes": "any other important information"
//             }`,
//         },
//       ],
//     })

//     // Extract the response content
//     const analysisText = response.choices[0].message.content

//     // Parse the JSON response
//     try {
//       const analysisJson = JSON.parse(analysisText || "{}")
//       return new Response(JSON.stringify(analysisJson), {
//         headers: {
//           "Content-Type": "application/json",
//         },
//       })
//     } catch (parseError) {
//       console.error("Error parsing AI response:", analysisText)
//       return new Response(
//         JSON.stringify({
//           error: "Failed to parse analysis results",
//           details: analysisText,
//         }),
//         {
//           status: 500,
//           headers: {
//             "Content-Type": "application/json",
//           },
//         },
//       )
//     }
//   } catch (error) {
//     console.error("Error in soil analysis:", error)
//     return new Response(
//       JSON.stringify({
//         error: "Failed to analyze soil parameters",
//         details: error instanceof Error ? error.message : "Unknown error",
//       }),
//       {
//         status: 500,
//         headers: {
//           "Content-Type": "application/json",
//         },
//       },
//     )
//   }
// }

















// import { openai } from "@ai-sdk/openai"
// import { generateText } from "ai"

// export async function POST(req: Request) {
//   try {
//     const soilData = await req.json()

//     const prompt = `As an agricultural expert, analyze the following soil parameters and provide detailed recommendations:

// Soil Parameters:
// - pH: ${soilData.ph}
// - Texture: ${soilData.texture}
// - Nitrogen: ${soilData.nitrogen}%
// - Phosphorus: ${soilData.phosphorus}%
// - Potassium: ${soilData.potassium}%
// - Organic Matter: ${soilData.organicMatter}%
// - Moisture: ${soilData.moisture}%
// - Temperature: ${soilData.temperature}°C
// - Location: ${soilData.location}
// - Depth: ${soilData.depth}cm

// Based on these parameters, provide:
// 1. A list of 5-8 crops that would grow well in these conditions
// 2. Specific fertilizer recommendations (2-3 options with type, amount, and frequency)
// 3. Detailed watering schedule and requirements

// Ensure the response is in the following JSON format:
// {
//   "recommendedCrops": ["crop1", "crop2", "crop3"],
//   "fertilizers": [
//     {
//       "type": "fertilizer name",
//       "amount": "amount per application",
//       "frequency": "application frequency"
//     }
//   ],
//   "wateringSchedule": {
//     "frequency": "how often to water",
//     "amount": "amount of water",
//     "notes": "additional watering instructions"
//   },
//   "additionalNotes": "any other important information"
// }`

//     const { text } = await generateText({
//       model: openai("gpt-4"),
//       prompt,
//       temperature: 0.7,
//       maxTokens: 1000,
//     })

//     // Ensure the response is valid JSON
//     try {
//       const analysis = JSON.parse(text)
//       return Response.json(analysis)
//     } catch (parseError) {
//       console.error("Error parsing AI response:", text)
//       return Response.json({ error: "Failed to parse AI response" }, { status: 500 })
//     }
//   } catch (error) {
//     console.error("Error analyzing soil:", error)
//     return Response.json({ error: "Failed to analyze soil parameters" }, { status: 500 })
//   }
// }



// import { openai } from "@ai-sdk/openai"
// import { generateText } from "ai"

// export async function POST(req: Request) {
//   const soilData = await req.json()

//   const prompt = `As an agricultural expert, analyze the following soil parameters and provide detailed recommendations:

// Soil Parameters:
// - pH: ${soilData.ph}
// - Texture: ${soilData.texture}
// - Nitrogen: ${soilData.nitrogen}%
// - Phosphorus: ${soilData.phosphorus}%
// - Potassium: ${soilData.potassium}%
// - Organic Matter: ${soilData.organicMatter}%
// - Moisture: ${soilData.moisture}%
// - Temperature: ${soilData.temperature}°C
// - Location: ${soilData.location}

// Please provide:
// 1. A list of crops that would grow well in these conditions
// 2. Specific fertilizer recommendations (type, amount, and frequency)
// 3. Detailed watering schedule and requirements

// Format the response as a JSON object with the following structure:
// {
//   "recommendedCrops": [],
//   "fertilizers": [{ "type": "", "amount": "", "frequency": "" }],
//   "wateringSchedule": { "frequency": "", "amount": "", "notes": "" },
//   "additionalNotes": ""
// }`

//   try {
//     const { text } = await generateText({
//       model: openai("gpt-4-turbo"),
//       prompt,
//     })

//     // Parse the AI response as JSON
//     const analysis = JSON.parse(text)

//     return Response.json(analysis)
//   } catch (error) {
//     console.error("Error analyzing soil:", error)
//     return Response.json({ error: "Failed to analyze soil parameters" }, { status: 500 })
//   }
// }

