import AgriChatbot from "../assistant/chats/AgriChatBot";
const AgriChat = async () => {
  return (
    <div className=" w-full h-[90vh] ">
        <AgriChatbot />
      </div>
  );
};


export default AgriChat;